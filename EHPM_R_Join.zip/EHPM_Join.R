rm(list = ls())       # Clear variables
require(foreign)
require(tidyverse)
## SET WORKING DIRECTORY:
path <- "/Users/emontero/Dropbox/Research_ElSalvador_LandReform/"
setwd(path)

##########
## 2008 ##
##########

# ID File: SEC00 -- level1id;
ehpm_2008_sec00 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2008/EHPM 2008/SEC00.sav"
                             ,to.data.frame = TRUE)
ehpm_2008_sec00 <- mutate(ehpm_2008_sec00,LEVELID=paste(LOTE,FOLIO, VIV))

# Demographics: SEC01
ehpm_2008_sec01 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2008/EHPM 2008/SEC01.sav"
                             ,to.data.frame = TRUE)
# r101 = order. r104=gender;r106=age.
ehpm_2008_sec01 <- mutate(ehpm_2008_sec01,order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Education: SEC02
ehpm_2008_sec02 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2008/EHPM 2008/SEC02.sav"
                             ,to.data.frame = TRUE)
# r201=order; r202a=literate; aproba1=yrs school;nivaprob=highest grade; gtmed=educ expenses;
ehpm_2008_sec02 <- mutate(ehpm_2008_sec02, order=R201, LEVELID=paste(LOTE,FOLIO, VIV))

# Occupation File:
ehpm_2008_sec04 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2008/EHPM 2008/SEC04.sav",
                             to.data.frame = TRUE)
ehpm_2008_sec04 <- mutate(ehpm_2008_sec04, order=R401, LEVELID=paste(LOTE,FOLIO, VIV))

# Ag File:
ehpm_2008_sec05 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2008/EHPM 2008/SEC05.sav",
                             to.data.frame = TRUE)
ehpm_2008_sec05 <- mutate(ehpm_2008_sec05, order=R501, LEVELID=paste(LOTE,FOLIO, VIV))

# Remits File:
ehpm_2008_sec07 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2008/EHPM 2008/SEC07.sav",
                             to.data.frame = TRUE)
ehpm_2008_sec07 <- mutate(ehpm_2008_sec07, order=R701, LEVELID=paste(LOTE,FOLIO, VIV))

# PG File:
ehpm_2008_sec0 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2008/EHPM 2008/SEC0.sav",
                            to.data.frame = TRUE)
ehpm_2008_sec0 <- mutate(ehpm_2008_sec0, LEVELID=paste(LOTE,FOLIO, VIV))


## Join together::
ehpm_2008 <- left_join(ehpm_2008_sec01,ehpm_2008_sec00,by=c("LEVELID"))
ehpm_2008 <- left_join(ehpm_2008,ehpm_2008_sec02,by=c("LEVELID","order"))
ehpm_2008 <- left_join(ehpm_2008,ehpm_2008_sec04,by=c("LEVELID","order"))
ehpm_2008 <- left_join(ehpm_2008,ehpm_2008_sec05,by=c("LEVELID","order"))
ehpm_2008 <- left_join(ehpm_2008,ehpm_2008_sec07,by=c("LEVELID","order"))
ehpm_2008 <- left_join(ehpm_2008,ehpm_2008_sec0,by=c("LEVELID"))

##########
## 2009 ##
##########

# ID File: SEC00 -- level1id;
ehpm_2009_sec00 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2009/EHPM 2009/SEC00.sav"
                             ,to.data.frame = TRUE)
ehpm_2009_sec00 <- mutate(ehpm_2009_sec00,LEVELID=paste(Lote,Folio, Viv))

# Demographics: SEC01
ehpm_2009_sec01 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2009/EHPM 2009/SEC01.sav"
                             ,to.data.frame = TRUE)
# r101 = order. r104=gender;r106=age.
ehpm_2009_sec01 <- mutate(ehpm_2009_sec01,order=R101, LEVELID=paste(Lote,Folio, Viv))

# Education: SEC02
ehpm_2009_sec02 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2009/EHPM 2009/SEC02.sav"
                             ,to.data.frame = TRUE)
# r201=order; r202a=literate; aproba1=yrs school;nivaprob=highest grade; gtmed=educ expenses;
ehpm_2009_sec02 <- mutate(ehpm_2009_sec02, order=R201, LEVELID=paste(Lote,Folio, Viv))

# Occupation File:
ehpm_2009_sec04 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2009/EHPM 2009/SEC04.sav",
                             to.data.frame = TRUE)
ehpm_2009_sec04 <- mutate(ehpm_2009_sec04, order=R401, LEVELID=paste(Lote,Folio, Viv))

# Ag File:
ehpm_2009_sec05 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2009/EHPM 2009/SEC05.sav",
                             to.data.frame = TRUE)
ehpm_2009_sec05 <- mutate(ehpm_2009_sec05, order=R501, LEVELID=paste(Lote,Folio, Viv))

# Remit File:
ehpm_2009_sec07 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2009/EHPM 2009/SEC07.sav",
                             to.data.frame = TRUE)
ehpm_2009_sec07 <- mutate(ehpm_2009_sec07, order=R701, LEVELID=paste(Lote,Folio, Viv))

# Dist PGs:
ehpm_2009_sec0 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2009/EHPM 2009/SEC0.sav",
                            to.data.frame = TRUE)
ehpm_2009_sec0 <- mutate(ehpm_2009_sec0, LEVELID=paste(Lote,Folio, Viv))

## Join together::
ehpm_2009 <- left_join(ehpm_2009_sec01,ehpm_2009_sec00,by=c("LEVELID"))
ehpm_2009 <- left_join(ehpm_2009,ehpm_2009_sec02,by=c("LEVELID","order"))
ehpm_2009 <- left_join(ehpm_2009,ehpm_2009_sec04,by=c("LEVELID","order"))
ehpm_2009 <- left_join(ehpm_2009,ehpm_2009_sec05,by=c("LEVELID","order"))
ehpm_2009 <- left_join(ehpm_2009,ehpm_2009_sec07,by=c("LEVELID","order"))
ehpm_2009 <- left_join(ehpm_2009,ehpm_2009_sec0,by=c("LEVELID"))

##########
## 2010 ##
##########

# ID File: SEC00 -- level1id;
ehpm_2010_sec00 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2010/EHPM 2010/SEC00.sav"
                             ,to.data.frame = TRUE)
ehpm_2010_sec00 <- mutate(ehpm_2010_sec00,LEVELID=paste(LOTE,FOLIO, VIV))

# Demographics: SEC01
ehpm_2010_sec01 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2010/EHPM 2010/SEC01.sav"
                             ,to.data.frame = TRUE)
# r101 = order. r104=gender;r106=age.
ehpm_2010_sec01 <- mutate(ehpm_2010_sec01,order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Education: SEC02
ehpm_2010_sec02 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2010/EHPM 2010/SEC02.sav"
                             ,to.data.frame = TRUE)
# r201=order; r202a=literate; aproba1=yrs school;nivaprob=highest grade; gtmed=educ expenses;
ehpm_2010_sec02 <- mutate(ehpm_2010_sec02, order=R201, LEVELID=paste(LOTE,FOLIO, VIV))

# Occupation File:
ehpm_2010_sec04 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2010/EHPM 2010/SEC04.sav",
                             to.data.frame = TRUE)
ehpm_2010_sec04 <- mutate(ehpm_2010_sec04, order=R401, LEVELID=paste(LOTE,FOLIO, VIV))

# Ag File:
ehpm_2010_sec05 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2010/EHPM 2010/SEC05.sav",
                             to.data.frame = TRUE)
ehpm_2010_sec05 <- mutate(ehpm_2010_sec05, order=R501, LEVELID=paste(LOTE,FOLIO, VIV))

# Remit File:
ehpm_2010_sec07 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2010/EHPM 2010/SEC07.sav",
                             to.data.frame = TRUE)
ehpm_2010_sec07 <- mutate(ehpm_2010_sec07, order=R701, LEVELID=paste(LOTE,FOLIO, VIV))

# PG File:
ehpm_2010_sec0 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2010/EHPM 2010/SEC0.sav",
                            to.data.frame = TRUE)
ehpm_2010_sec0 <- mutate(ehpm_2010_sec0, LEVELID=paste(LOTE,FOLIO, VIV))

## Join together::
ehpm_2010 <- left_join(ehpm_2010_sec01,ehpm_2010_sec00,by=c("LEVELID"))
ehpm_2010 <- left_join(ehpm_2010,ehpm_2010_sec02,by=c("LEVELID","order"))
ehpm_2010 <- left_join(ehpm_2010,ehpm_2010_sec04,by=c("LEVELID","order"))
ehpm_2010 <- left_join(ehpm_2010,ehpm_2010_sec05,by=c("LEVELID","order"))
ehpm_2010 <- left_join(ehpm_2010,ehpm_2010_sec07,by=c("LEVELID","order"))
ehpm_2010 <- left_join(ehpm_2010,ehpm_2010_sec0,by=c("LEVELID"))

##########
## 2011 ##
##########

# ID File: SEC00 -- level1id;
ehpm_2011_sec00 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2011/EHPM 2011/BDSEC00.sav"
                             ,to.data.frame = TRUE)
ehpm_2011_sec00 <- mutate(ehpm_2011_sec00,LEVELID=paste(LOTE,FOLIO, VIV))

# Demographics: SEC01
ehpm_2011_sec01 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2011/EHPM 2011/BDSEC01.sav"
                             ,to.data.frame = TRUE)
# r101 = order. r104=gender;r106=age.
ehpm_2011_sec01 <- mutate(ehpm_2011_sec01,order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Education: SEC02
ehpm_2011_sec02 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2011/EHPM 2011/BDSEC02.sav"
                             ,to.data.frame = TRUE)
# r201=order; r202a=literate; aproba1=yrs school;nivaprob=highest grade; gtmed=educ expenses;
ehpm_2011_sec02 <- mutate(ehpm_2011_sec02, order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Occupation File:
ehpm_2011_sec04 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2011/EHPM 2011/BDSEC04.sav",
                             to.data.frame = TRUE)
ehpm_2011_sec04 <- mutate(ehpm_2011_sec04, order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Ag File:
ehpm_2011_sec05 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2011/EHPM 2011/BDSEC05.sav",
                             to.data.frame = TRUE)
ehpm_2011_sec05 <- mutate(ehpm_2011_sec05, order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Remit File:
ehpm_2011_sec07 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2011/EHPM 2011/DBSEC07.sav",
                             to.data.frame = TRUE)
ehpm_2011_sec07 <- mutate(ehpm_2011_sec07, order=R701, LEVELID=paste(LOTE,FOLIO, VIV))

# PG File:
ehpm_2011_sec0 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2011/EHPM 2011/BDSEC0.sav",
                            to.data.frame = TRUE)
ehpm_2011_sec0 <- mutate(ehpm_2011_sec0, LEVELID=paste(LOTE,FOLIO, VIV))


## Join together::
ehpm_2011 <- left_join(ehpm_2011_sec01,ehpm_2011_sec00,by=c("LEVELID"))
ehpm_2011 <- left_join(ehpm_2011,ehpm_2011_sec02,by=c("LEVELID","order"))
ehpm_2011 <- left_join(ehpm_2011,ehpm_2011_sec04,by=c("LEVELID","order"))
ehpm_2011 <- left_join(ehpm_2011,ehpm_2011_sec05,by=c("LEVELID","order"))
ehpm_2011 <- left_join(ehpm_2011,ehpm_2011_sec07,by=c("LEVELID","order"))
ehpm_2011 <- left_join(ehpm_2011,ehpm_2011_sec0,by=c("LEVELID"))

##########
## 2012 ##
##########

# ID File: SEC00 -- level1id;
ehpm_2012_sec00 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2012/EHPM 2012/SEC00.sav"
                             ,to.data.frame = TRUE)
ehpm_2012_sec00 <- mutate(ehpm_2012_sec00,LEVELID=paste(LOTE,FOLIO, VIV))

# Demographics: SEC01
ehpm_2012_sec01 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2012/EHPM 2012/SEC01.sav"
                             ,to.data.frame = TRUE)
# r101 = order. r104=gender;r106=age.
ehpm_2012_sec01 <- mutate(ehpm_2012_sec01,order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Education: SEC02
ehpm_2012_sec02 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2012/EHPM 2012/SEC02.sav"
                             ,to.data.frame = TRUE)
# r201=order; r202a=literate; aproba1=yrs school;nivaprob=highest grade; gtmed=educ expenses;
ehpm_2012_sec02 <- mutate(ehpm_2012_sec02, order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Occupation File:
ehpm_2012_sec04 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2012/EHPM 2012/SEC04.sav",
                             to.data.frame = TRUE)
ehpm_2012_sec04 <- mutate(ehpm_2012_sec04, order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Ag File:
ehpm_2012_sec05 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2012/EHPM 2012/SEC05.sav",
                             to.data.frame = TRUE)
ehpm_2012_sec05 <- mutate(ehpm_2012_sec05, order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Remit File:
ehpm_2012_sec07 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2012/EHPM 2012/SEC07.sav",
                             to.data.frame = TRUE)
ehpm_2012_sec07 <- mutate(ehpm_2012_sec07, order=R701, LEVELID=paste(LOTE,FOLIO, VIV))

## Join together::
ehpm_2012 <- left_join(ehpm_2012_sec01,ehpm_2012_sec00,by=c("LEVELID"))
ehpm_2012 <- left_join(ehpm_2012,ehpm_2012_sec02,by=c("LEVELID","order"))
ehpm_2012 <- left_join(ehpm_2012,ehpm_2012_sec04,by=c("LEVELID","order"))
ehpm_2012 <- left_join(ehpm_2012,ehpm_2012_sec05,by=c("LEVELID","order"))
ehpm_2012 <- left_join(ehpm_2012,ehpm_2012_sec07,by=c("LEVELID","order"))

##########
## 2013 ##
##########

# ID File: SEC00 -- level1id;
ehpm_2013_sec00 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2013/EHPM 2013/SEC00.sav"
                             ,to.data.frame = TRUE)
ehpm_2013_sec00 <- mutate(ehpm_2013_sec00,LEVELID=paste(LOTE,FOLIO, VIV))

# Demographics: SEC01
ehpm_2013_sec01 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2013/EHPM 2013/SEC01.sav"
                             ,to.data.frame = TRUE)
# r101 = order. r104=gender;r106=age.
ehpm_2013_sec01 <- mutate(ehpm_2013_sec01,order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Education: SEC02
ehpm_2013_sec02 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2013/EHPM 2013/SEC02.sav"
                             ,to.data.frame = TRUE)
# r201=order; r202a=literate; aproba1=yrs school;nivaprob=highest grade; gtmed=educ expenses;
ehpm_2013_sec02 <- mutate(ehpm_2013_sec02, order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Occupation File:
ehpm_2013_sec04 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2013/EHPM 2013/SEC04.sav",
                             to.data.frame = TRUE)
ehpm_2013_sec04 <- mutate(ehpm_2013_sec04, order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Ag File:
ehpm_2013_sec05 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2013/EHPM 2013/SEC05.sav",
                             to.data.frame = TRUE)
ehpm_2013_sec05 <- mutate(ehpm_2013_sec05, order=R101, LEVELID=paste(LOTE,FOLIO, VIV))

# Remit File:
ehpm_2013_sec07 <- read.spss(file = "./Data/EHPM/wetransfer-7d7285/EHPM 2013/EHPM 2013/SEC07.sav",
                             to.data.frame = TRUE)
ehpm_2013_sec07 <- mutate(ehpm_2013_sec07, order=R701, LEVELID=paste(LOTE,FOLIO, VIV))

## Join together::
ehpm_2013 <- left_join(ehpm_2013_sec01,ehpm_2013_sec00,by=c("LEVELID"))
ehpm_2013 <- left_join(ehpm_2013,ehpm_2013_sec02,by=c("LEVELID","order"))
ehpm_2013 <- left_join(ehpm_2013,ehpm_2013_sec04,by=c("LEVELID","order"))
ehpm_2013 <- left_join(ehpm_2013,ehpm_2013_sec05,by=c("LEVELID","order"))
ehpm_2013 <- left_join(ehpm_2013,ehpm_2013_sec07,by=c("LEVELID","order"))

## Append All EHPMs Together:
ehpm <- bind_rows(ehpm_2000, ehpm_2001, ehpm_2002,
                  ehpm_2004, ehpm_2005, ehpm_2006,
                  ehpm_2007, ehpm_2008, ehpm_2009,
                  ehpm_2010,ehpm_2011, ehpm_2012,
                  ehpm_2013)